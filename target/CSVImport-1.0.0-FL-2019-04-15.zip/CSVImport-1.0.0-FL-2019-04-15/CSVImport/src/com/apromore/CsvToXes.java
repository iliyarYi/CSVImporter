package com.apromore;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.util.List;
import org.deckfour.xes.extension.std.XConceptExtension;
import org.deckfour.xes.extension.std.XLifecycleExtension;
import org.deckfour.xes.extension.std.XTimeExtension;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.factory.XFactoryBufferedImpl;
import org.deckfour.xes.model.XAttribute;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;
import org.deckfour.xes.out.XesXmlSerializer;
import org.zkoss.util.media.Media;
import org.zkoss.zhtml.Messagebox;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.EventListener;
import org.zkoss.zul.Listbox;
import org.zkoss.zul.Listitem;


import com.opencsv.CSVReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.deckfour.xes.model.impl.XAttributeLiteralImpl;
import org.deckfour.xes.model.impl.XAttributeTimestampImpl;


// TODO: Auto-generated Javadoc
/**
 * The Class CsvToXes.
 */
public class CsvToXes {


	/** The case id values. */
	private String[] caseIdValues = {"case", "case id", "case-id"};

	/** The activity values. */
	private String[] activityValues = {"activity", "activity id", "activity-id"};

	/** The timestamp Values. */
	private String[] timestampValues = {"timestamp", "end date", "time stamp"};

	/** The other Timestamps. */
	private String[] otherTimestamps = {"start date","creation_time", "log_start_time"};

	/** The Constant caseid. */
	private static final String caseid = "caseid";

	/** The Constant activity. */
	private static final String activity = "activity";

	/** The Constant timestamp. */
	private static final String timestamp = "timestamp";

	private List<Listbox> lists;
	private HashMap<String, Integer> heads;

	/**
	 * Prepare xes model.
	 *
	 * @param media the media
	 * @return the list
	 */
	@SuppressWarnings("resource")
	public List<LogModel> prepareXesModel(Media media) {
		CSVReader reader = null;

		try {
//			reader = new CSVReader(new InputStreamReader(media.getStreamData()));

			if(media.isBinary()){
				reader = new CSVReader(new InputStreamReader(media.getStreamData()));
			}
			else{
				reader = new CSVReader(media.getReaderData());
			}

			// read first line from CSV as header
			String[] header = reader.readNext();
			// get mandatory fields position in the header array
			HashMap<String, Integer> heads = headerPos(header);

			// add attribute drop down lists
			setLists(header.length, heads);


			// If any of the mandatory fields are missing show alert message to the user and return
			StringBuilder headNOTDefined = checkFields(heads) ;
			if(headNOTDefined.length() !=0) {
				Messagebox.show(headNOTDefined.toString());
				return null;
			}



			// create model "LogModel" of the log data
			// We set mandatory fields and other fields are set with hash map
			String[] line;
			List<LogModel> logData = new ArrayList<LogModel>();
			HashMap<String, String> others = new HashMap<String, String>();
			String foramte = null;

			while ((line = reader.readNext()) != null) {

				others = new HashMap<String, String>();
				for(int p=0; p<= line.length-1; p++) {
					if(p!= heads.get(caseid) && p!= heads.get(activity) && p!= heads.get(timestamp)) {
						others.put(header[p], line[p]);
					}
				}


				Parse parse = new Parse();
				if(foramte == null) {
					foramte = parse.determineDateFormat(line[heads.get(timestamp)]);
				}
				Timestamp tStamp =  parse.parseTimestamp(line[heads.get(timestamp)], foramte);

				logData.add(new LogModel(line[heads.get(caseid)], line[heads.get(activity)], tStamp , others));

			}
			reader.close();
			return logData;

		} catch (IOException e) {
			e.printStackTrace();
			Messagebox.show(e.getMessage());
		}
		return null;
	}


	/**
	 * Header pos.
	 *
	 * @param line read line from CSV
	 * @return the hash map: including mandatory field as key and position in the array as the value.
	 */
	private HashMap<String, Integer> headerPos(String[] line) {
		HashMap<String, Integer> pos = new HashMap<String, Integer>();
		for(int i=0; i<= line.length -1; i++) {
			if((pos.get(caseid) == null) && getPos(caseIdValues, line[i])) pos.put(caseid, i);
			if((pos.get(activity) == null) && getPos(activityValues, line[i])) pos.put(activity, i);
			if((pos.get(timestamp) == null) && getPos(timestampValues, line[i])) pos.put(timestamp, i);
		}
		return pos;
	}

	/**
	 * Gets the pos.
	 *
	 * @param col the col: array which has possible names for each of the mandatory fields.
	 * @param elem the elem: one item of the CSV line array
	 * @return the pos: boolean value confirming if the elem is the required element.
	 */
	private Boolean getPos(String[] col, String elem) {
		return	Arrays.stream(col).anyMatch(elem.toLowerCase()::equals);
	}

	/**
	 * Check fields.
	 *
	 * Check if all mandatory fields are found in the file, otherwise, construct a message based on the missed fields.
	 *
	 * @param posMap the pos map
	 * @return the string builder
	 */
	private StringBuilder checkFields(HashMap<String, Integer> posMap) {
		String[] fieldsToCheck = {caseid,activity,timestamp};
		StringBuilder importMessage = new StringBuilder();

		for(int f=0; f<=fieldsToCheck.length -1; f++) {
			if(posMap.get(fieldsToCheck[f]) == null) {
				String mess = "No " + fieldsToCheck[f] + " defined!";
				importMessage = (importMessage.length() == 0?  importMessage.append(mess) :  importMessage.append(", " + mess));
			}
		}

		return importMessage;
	}




	/**
	 * Creates the X log.
	 *
	 *	create xlog element, assign respective extensions and attributes for each event and trace
	 * @param traces the traces
	 * @return the x log
	 */
	public XLog createXLog(List<LogModel> traces){
		if(traces == null) return null;

		XFactory xFactory = new XFactoryBufferedImpl();
		XLog xLog = xFactory.createLog();
		XTrace xTrace = null;
		XEvent xEvent = null;

		// declare standard extensions of the log
		XConceptExtension concept = XConceptExtension.instance();
		XLifecycleExtension lifecycle = XLifecycleExtension.instance();
		XTimeExtension timestamp = XTimeExtension.instance();

		xLog.getExtensions().add(concept);
		xLog.getExtensions().add(lifecycle);
		xLog.getExtensions().add(timestamp);

		lifecycle.assignModel(xLog, XLifecycleExtension.VALUE_MODEL_STANDARD);

		String newTraceID = null;	// to keep track of traces, when a new trace is created we assign its value and add the respective events for the trace.
		String foramte = null;

		for (LogModel trace : traces) {
			String caseID = trace.getCaseID();

			if(newTraceID == null || !newTraceID.equals(caseID)){	// This could be new trace
				xTrace = null;	// reinitialize xTrace variable

				// loop through existing traces to check if it already exists before creating new trace
				List<XTrace> theTraces = xLog;
				for(XTrace tr: theTraces) {
					if(caseID.equals(tr.getAttributes().get("concept:name").toString())) {
						xTrace = tr;
						break;
					}
				}

				// if the trace does not exist, create new one.
				if(xTrace == null) {
					xTrace = xFactory.createTrace();
					concept.assignName(xTrace, caseID);
					xLog.add(xTrace);
				}
				newTraceID = caseID;
			}

			// create events for the current trace, assign the respective attributes.
			xEvent = xFactory.createEvent();
			concept.assignName(xEvent, trace.getConcept());
			lifecycle.assignStandardTransition(xEvent, XLifecycleExtension.StandardModel.COMPLETE);
			timestamp.assignTimestamp(xEvent, trace.getTimestamp());


			HashMap<String, String> others = trace.getOthers();
			for (String key : others.keySet()) {
				XAttribute attribute;

				// if true, then this attribute could be timestamp type
				if(getPos(otherTimestamps, key)) {
					Parse parse = new Parse();
					if(foramte == null) {
						foramte = parse.determineDateFormat(others.get(key));
					}
					Timestamp tStamp =  parse.parseTimestamp(others.get(key), foramte);
					attribute = new XAttributeTimestampImpl(key, tStamp);

				}
				else {
					attribute = new XAttributeLiteralImpl(key, others.get(key));
				}

				xEvent.getAttributes().put(key, attribute);
			}

			xTrace.add(xEvent);
		}


		return xLog;
	}


	/**
	 * To XES file.
	 *
	 *	Serialize xLog to XES file.
	 *
	 * @param xLog the x log
	 * @throws FileNotFoundException the file not found exception
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	public void toXESfile(XLog xLog) throws FileNotFoundException, IOException {
		if(xLog == null) return;

		XesXmlSerializer serializer = new XesXmlSerializer();
		serializer.serialize(xLog, new FileOutputStream(new File("test.xes")));
		Messagebox.show("Your file has been created!");

	}


	public void setHeads(String[] header) {
		this.heads = headerPos(header);
	}

	public HashMap<String, Integer> getHeads() {
		return heads;
	}

	public void setLists(int cols, HashMap<String, Integer> heads) {
		// create a list for each column
		// select value bases on detected attribute
		// when converting, get selected value.
		lists = new ArrayList<Listbox>();
		String [] menuItems = {"Case ID", "Activity", "End timestamp", "Other"};

		int caseIdCol, activityCol,timestampCol;
		if (heads.isEmpty()){
			caseIdCol = activityCol = timestampCol = -1;
		}
		else {
			caseIdCol = ((heads.get(caseid)== null)? -1 : heads.get(caseid));
			activityCol = ((heads.get(activity)== null)? -1 : heads.get(activity));
			timestampCol = ((heads.get(timestamp)== null)? -1 : heads.get(timestamp));
		}

		List<Integer> selected = new ArrayList<Integer>();

		for(int cl =0; cl<=cols-1; cl++) {

			Listbox box = new Listbox();
			box.setMold("select"); // set listBox to select mode

			for(int it=0; it<= menuItems.length-1; it++) {
				Listitem item = new Listitem();
				item.setLabel(menuItems[it]);
				if((it==0 && cl == caseIdCol) ||(it==1 && cl == activityCol) ||(it==2 && cl == timestampCol)||(it == 3)) {
					item.setSelected(true);
				}

				box.appendChild(item);
			}

			box.addEventListener("onSelect", new EventListener() {
				public void onEvent(Event event) {
					Messagebox.show("You changed your selection!");
				}
			});


			lists.add(box);
		}
	}


	public List<Listbox> getLists() {
		return lists;
	}

}
