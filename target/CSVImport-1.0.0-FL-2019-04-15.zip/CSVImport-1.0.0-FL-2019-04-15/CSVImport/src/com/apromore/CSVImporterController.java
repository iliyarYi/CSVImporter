package com.apromore;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import org.deckfour.xes.model.XLog;
import org.zkoss.util.media.Media;
import org.zkoss.zul.Button;
import org.zkoss.zhtml.Messagebox;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.UploadEvent;
import org.zkoss.zk.ui.select.SelectorComposer;
import org.zkoss.zk.ui.select.annotation.Listen;
import org.zkoss.zk.ui.select.annotation.Wire;
import org.zkoss.zul.Div;
import org.zkoss.zul.Grid;
import org.zkoss.zul.ListModel;
import org.zkoss.zul.ListModelList;
import org.zkoss.zul.Listbox;

import com.opencsv.CSVReader;

// TODO: Auto-generated Javadoc

/**
 * The Class CSVImporterController.
 * <p>
 * import CSV file from user, display content into the page.
 */
public class CSVImporterController extends SelectorComposer<Component> {


    /**
     * The my grid.
     */
    @Wire
    private Grid myGrid;

    @Wire
    private Div attrBox;

    @Wire
    private Button toXESButton;

    private Media media;
    /**
     * Upload file.
     *
     * @param event the event: upload event
     *              allows importing CSV file, if imported correctly, it sets the grid model and row renderer.
     */
    @Listen("onUpload = #uploadFile")
    public void uploadFile(UploadEvent event) {

         this.media = event.getMedia();

        String[] allowedExtensions = {"csv", "xls", "xlsx"};
        if (Arrays.asList(allowedExtensions).contains(media.getFormat())) {

            // set grid model
            myGrid.setModel(displayCSVContent(media));

            //set grid row renderer
            gridRendererController rowRenderer = new gridRendererController();
            myGrid.setRowRenderer(rowRenderer);

            toXESButton.setDisabled(false);

        } else {
            Messagebox.show("Please select CSV file!", "Error", Messagebox.OK, Messagebox.ERROR);
        }
    }

    /**
     * Gets the Content.
     *
     * @param media the imported CSV file
     * @return the model data
     * <p>
     * read CSV content and create list model to be set as grid model.
     */
    @SuppressWarnings("null")
    private ListModel<String[]> displayCSVContent(Media media) {
        CSVReader reader = null;
        CsvToXes CsvToXes = new CsvToXes();

        try {

            if(media.isBinary()) {
                reader = new CSVReader(new InputStreamReader(media.getStreamData()));
            } else {
                reader = new CSVReader(media.getReaderData());
            }
            ListModelList<String[]> result = new ListModelList<String[]>();
            String[] line;


            // display first numberOfrows to user and display drop down lists to set attributes

            line = reader.readNext();

            CsvToXes.setHeads(line);
            CsvToXes.setLists(line.length, CsvToXes.getHeads());

            List<Listbox> lists = CsvToXes.getLists();
            for (Listbox list : lists) {
                attrBox.appendChild(list);
            }
            attrBox.clone();

            int numberOfrows = 100;    // display first 100 rows
            while (line != null && numberOfrows >= 0) {
                result.add(line);
                numberOfrows--;
                line = reader.readNext();
            }
            reader.close();
            return result;

        } catch (IOException e) {
            e.printStackTrace();
            Messagebox.show(e.getMessage());
            return null;
        }
    }


    @Listen("onClick = #toXESButton")
    public void toXES() throws IOException{

        if (media != null){
            CsvToXes CsvToXes = new CsvToXes();
            // create xes file
            List<LogModel> xesModel = CsvToXes.prepareXesModel(media);

            if (xesModel != null) {
                // create XES file
                XLog xlog = CsvToXes.createXLog(xesModel);
                CsvToXes.toXESfile(xlog);
            }

        }else{

            Messagebox.show("Upload file first!");

        }
    }

}
